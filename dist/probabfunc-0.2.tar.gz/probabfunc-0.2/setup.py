from setuptools import setup

setup(name='probabfunc',
      version='0.2',
      description='Gaussian and Binomial/Normal distributions',
      packages=['probabfunc'],
      author='Dhiraj Kumar Chaudhary',
      author_email='dhirajc963@gmail.com',
      zip_safe=False)